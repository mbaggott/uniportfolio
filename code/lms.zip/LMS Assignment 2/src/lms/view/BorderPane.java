package lms.view;

import java.awt.*;
import javax.swing.*;

@SuppressWarnings("serial")
//GUI Class
public class BorderPane extends JPanel {
    
    // *** CONSTRUCTOR ***
    //Set layout of BorderPane Jpanel to BorderLayout
    public BorderPane() {
        this.setLayout(new BorderLayout());
    }
}
